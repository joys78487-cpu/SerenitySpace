// Persistent audio player
let audioPlayer = window.audioPlayer || null;

function initAudio() {
    if (!audioPlayer) {
        audioPlayer = new Audio("/static/calmcore/audio/calm.mp3");
        audioPlayer.loop = true;
        window.audioPlayer = audioPlayer;

        // Restore previous state
        if (sessionStorage.getItem("audioPlaying") === "true") {
            audioPlayer.play();
        }
    }

    const btn = document.getElementById("play-pause-btn");
    if (!btn) return;

    // Update button text
    btn.textContent = audioPlayer.paused ? "Play" : "Pause";

    btn.addEventListener("click", () => {
        if (audioPlayer.paused) {
            audioPlayer.play();
            btn.textContent = "Pause";
            sessionStorage.setItem("audioPlaying", "true");
        } else {
            audioPlayer.pause();
            btn.textContent = "Play";
            sessionStorage.setItem("audioPlaying", "false");
        }
    });
}

window.addEventListener("DOMContentLoaded", initAudio);
