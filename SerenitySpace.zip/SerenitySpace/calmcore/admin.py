from django.contrib import admin
from .models import JournalEntry, CalmPrompt, Gratitude  # only import models that exist

admin.site.register(JournalEntry)
admin.site.register(CalmPrompt)
admin.site.register(Gratitude)
