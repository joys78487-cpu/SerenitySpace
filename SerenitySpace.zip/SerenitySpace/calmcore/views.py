from django.shortcuts import render, redirect
from .models import JournalEntry
from django.utils import timezone

def home(request):
    return render(request, 'calmcore/home.html')


def journal(request):
    if request.method == "POST":
        text = request.POST.get("text")
        if text:
            JournalEntry.objects.create(text=text, created_at=timezone.now())
            return redirect('journal')

    entries = JournalEntry.objects.order_by('-created_at')
    return render(request, 'calmcore/journal.html', {'entries': entries})