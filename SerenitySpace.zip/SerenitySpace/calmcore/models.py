from django.db import models
from django.utils import timezone

class JournalEntry(models.Model):
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)  # automatically set when created

    def __str__(self):
        return self.text[:50]


class CalmPrompt(models.Model):
    prompt = models.TextField()  # renamed from 'text'
    created_at = models.DateTimeField(auto_now_add=True)  # automatically set when created

    def __str__(self):
        return self.prompt[:50]


class Gratitude(models.Model):
    note = models.TextField()  # renamed from 'text'
    created_at = models.DateTimeField(auto_now_add=True)  # automatically set when created

    def __str__(self):
        return self.note[:50]
