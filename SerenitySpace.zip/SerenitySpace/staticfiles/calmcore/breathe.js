const audio = document.getElementById("calmAudio");

function toggleMusic() {
    if (audio.paused) {
        audio.play();
    } else {
        audio.pause();
    }
}

const text = document.getElementById("breath-text");
let inhale = true;

setInterval(() => {
    text.innerText = inhale ? "Breathe Out" : "Breathe In";
    inhale = !inhale;
}, 4000);

function toggleMusic() {
    const audio = document.getElementById("calmAudio");
    audio.paused ? audio.play() : audio.pause();
}
